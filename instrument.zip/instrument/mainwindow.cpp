#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLabel>
#include <QFont>
#include <QPixmap>
#include "textlabel.h"

MainWindow::MainWindow(QWidget *parent):
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
//    QTimer * timer = new QTimer(this);
//    connect(timer,SIGNAL(timeout()),this,SLOT(ontest()));
//    timer->start(50);
    carspeed =0 ;
    carrpm=0;
    longpresstime=0;
    init_left();
    init_left_date();
    init_left_ui();
//    label_ctrl_start->setX(0*factor);
//    label_ctrl_start->setY(0*factor);
//    label_ctrl_start->setW(100*factor);
//    label_ctrl_start->setH(100*factor);
//    label_ctrl_start->setGeometry(1450*factor,400*factor,300*factor,300*factor);
//    label_ctrl_start->setP(":/icon/start.png");
//   connect(label_ctrl_start,SIGNAL(pressed()),this,SLOT(onbutton()));
    init_right();
    init_right_date();
    init_right_ui();
    init_connect();
    //repaint();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::init_left()
{
    label_background=new Backlabel(this);
    label_safety=new QLabel((QLabel*)label_background);
    label_oil=new QLabel((QLabel*)label_background);
    label_temp=new QLabel((QLabel*)label_background);
    label_engine=new QLabel((QLabel*)label_background);
    label_door=new QLabel((QLabel*)label_background);
    label_led=new QLabel((QLabel*)label_background);
    label_ble=new QLabel((QLabel*)label_background);
    label_turn_left=new QLabel((QLabel*)label_background);
    label_turn_right=new QLabel((QLabel*)label_background);
    label_bottom = new QLabel((QLabel*)label_background);
    label_car = new QLabel((QLabel*)label_background);

    text_info = new Textlabel((QLabel*)label_background);
    text_speed = new Textlabel((QLabel*)label_background);
    text_rpm = new Textlabel((QLabel*)label_background);
}

void MainWindow::init_left_date()
{
    struct IconInfo info;
    //安全带
    info.widget=label_safety;
    info.x=577;
    info.y=605;
    info.w=24;
    info.h=24;
    info.p_on=QString(":/pic/safety_on_1.png");
    info.p_off=QString(":/pic/safety_off_1.png");
    left_info<<info;
    //油压表
    info.widget=label_oil;
    info.x=615;
    info.y=605;
    info.w=24;
    info.h=24;
    info.p_on=QString(":/pic/oil_on_1.png");
    info.p_off=QString(":/pic/oil_off_1.png");
    left_info<<info;
    //水温表
    info.widget=label_temp;
    info.x=653;
    info.y=605;
    info.w=24;
    info.h=24;
    info.p_on=QString(":/pic/temp_on_1.png");
    info.p_off=QString(":/pic/temp_off_1.png");
    left_info<<info;
    //发动机
    info.widget=label_engine;
    info.x=691;
    info.y=605;
    info.w=24;
    info.h=24;
    info.p_on=QString(":/pic/engine_on_1.png");
    info.p_off=QString(":/pic/engine_off_1.png");
    left_info<<info;
    //车门
    info.widget=label_door;
    info.x=729;
    info.y=605;
    info.w=24;
    info.h=24;
    info.p_on=QString(":/pic/door_on_1.png");
    info.p_off=QString(":/pic/door_off_1.png");
    left_info<<info;
    //led灯
    info.widget=label_led;
    info.x=767;
    info.y=605;
    info.w=24;
    info.h=24;
    info.p_on=QString(":/pic/led_on_1.png");
    info.p_off=QString(":/pic/led_off_1.png");
    left_info<<info;
    //蓝牙
    info.widget=label_ble;
    info.x=805;
    info.y=605;
    info.w=24;
    info.h=24;
    info.p_on=QString(":/pic/ble_on_1.png");
    info.p_off=QString(":/pic/ble_off_1.png");
    left_info<<info;
    //左转
    info.widget=label_turn_left;
    info.x=515;
    info.y=278;
    info.w=21;
    info.h=22.07;
    info.p_on=QString(":/pic/left_on_1.png");
    info.p_off=QString(":/pic/left_off_1.png");
    left_info<<info;
    //右转
    info.widget=label_turn_right;
    info.x=868;
    info.y=278;
    info.w=21;
    info.h=22.07;
    info.p_on=QString(":/pic/right_on_1.png");
    info.p_off=QString(":/pic/right_off_1.png");
    left_info<<info;
    //小车
    info.widget=label_car;
    info.x=596;
    info.y=368;
    info.w=202;
    info.h=152;
    info.p_on=QString(":/pic/P.png");
    info.p_off=QString(":/pic/P.png");
    left_info<<info;
    //底座
    info.widget=label_bottom;
    info.x=567;
    info.y=474;
    info.w=258;
    info.h=38;
    info.p_on=QString(":/pic/bottom_1.png");
    info.p_off=QString("");
    left_info<<info;

    //速度
    info.widget=text_speed;
    info.x=990;
    info.y=447;
    info.w=108;
    info.h=70;
    left_info<<info;
    //转速
    info.widget=text_rpm;
    info.x=330;
    info.y=447;
    info.w=108;
    info.h=70;
    left_info<<info;
    //提示文字
    info.widget=text_info;
    info.x=536;
    info.y=278;
    info.w=330;
    info.h=24;
    left_info<<info;

    carlist<<QString(":/pic/car_s_1.png")
          <<QString(":/pic/car_s_2.png")
         <<QString(":/pic/car_s_3.png")
        <<QString(":/pic/car_s_4.png");
    gearlist<<QString(":/pic/P.png")
           <<QString(":/pic/R.png")
          <<QString(":/pic/N.png")
         <<QString(":/pic/D.png");
}

void MainWindow::init_left_ui()
{
    for(int i=0;i<11;i++)
    {
        int x=left_info.at(i).x;
        int y=left_info[i].y;
        int w=left_info[i].w;
        int h=left_info[i].h;
        QString p=left_info[i].p_off;
        QLabel *label=(QLabel*)(left_info[i].widget);
        label->setGeometry(x*factor,y*factor,w*factor,h*factor);
        drawLabelPic(label,p);
    }
    text_info->setGeometry(left_info[13].x*factor,
           left_info[13].y*factor,left_info[13].w*factor,
            left_info[13].h*factor );
    text_info->setLabelText("测试中",12);
    text_speed->setGeometry(left_info[11].x*factor,
           left_info[11].y*factor,left_info[11].w*factor,
            left_info[11].h*factor );
    text_speed->setLabelText("200",35);
    text_rpm->setGeometry(left_info[12].x*factor,
           left_info[12].y*factor,left_info[12].w*factor,
            left_info[12].h*factor );
    text_rpm->setLabelText("3.6",35);
}

void MainWindow::init_right()
{
    label_ctrl=new QLabel(this);
    label_wheel=new QLabel(label_ctrl);
    label_ctrl_start=new ClickLabel((QLabel*)label_ctrl);
    label_ctrl_turn_left=new ClickLabel((QLabel*)label_ctrl);
    label_ctrl_turn_right=new ClickLabel((QLabel*)label_ctrl);
    label_ctrl_up=new ClickLabel((QLabel*)label_ctrl);
    label_ctrl_down=new ClickLabel((QLabel*)label_ctrl);
    label_ctrl_acc=new ClickLabel((QLabel*)label_ctrl);
    label_ctrl_dac=new ClickLabel((QLabel*)label_ctrl);
    label_ctrl_left=new ClickLabel((QLabel*)label_ctrl);
    label_ctrl_right=new ClickLabel((QLabel*)label_ctrl);
}

void MainWindow::init_right_date()
{
    struct IconInfo info;
    info.widget=label_ctrl;
    info.x=1396;
    info.y=0;
    info.w=800;
    info.h=600;
    info.p_on=QString(":/icon/bg.png");
    right_info<<info;

    info.widget=label_wheel;
    info.x=100;
    info.y=114;
    info.w=600;
    info.h=373.09;
    info.p_on=QString(":/icon/wheel.png");
    right_info<<info;

    info.widget=label_ctrl_start;
    info.x=359.64;
    info.y=243.61;
    info.w=80;
    info.h=80;
    info.p_on=QString(":/icon/start.png");
    right_info<<info;

    info.widget=label_ctrl_turn_left;
    info.x=162;
    info.y=273;
    info.w=64;
    info.h=40;
    info.p_on=QString(":/icon/turn_left.png");
    right_info<<info;

    info.widget=label_ctrl_turn_right;
    info.x=162;
    info.y=230;
    info.w=64;
    info.h=42.86;
    info.p_on=QString(":/icon/turn_right.png");
    right_info<<info;

    info.widget=label_ctrl_up;
    info.x=575;
    info.y=229;
    info.w=64;
    info.h=42.86;
    info.p_on=QString(":/icon/up.png");
    right_info<<info;

    info.widget=label_ctrl_down;
    info.x=575;
    info.y=273;
    info.w=64;
    info.h=40;
    info.p_on=QString(":/icon/down.png");
    right_info<<info;

    info.widget=label_ctrl_acc;
    info.x=405;
    info.y=382;
    info.w=47.5;
    info.h=45;
    info.p_on=QString(":/icon/accelerate.png");
    right_info<<info;

    info.widget=label_ctrl_dac;
    info.x=348;
    info.y=382;
    info.w=47.5;
    info.h=45;
    info.p_on=QString(":/icon/moderate.png");
    right_info<<info;

    info.widget=label_ctrl_left;
    info.x=320;
    info.y=243;
    info.w=40;
    info.h=64;
    info.p_on=QString(":/icon/test_l.png");
    right_info<<info;

    info.widget=label_ctrl_right;
    info.x=440;
    info.y=243;
    info.w=40;
    info.h=64;
    info.p_on=QString(":/icon/test_r.png");
    right_info<<info;
}

void MainWindow::init_right_ui()
{
    label_ctrl->setGeometry(right_info[0].x*factor,right_info[0].y*factor,right_info[0].w*factor,right_info[0].h*factor);
    label_wheel->setGeometry(right_info[1].x*factor,right_info[1].y*factor,right_info[1].w*factor,right_info[1].h*factor);
    drawLabelPic(label_ctrl,right_info[0].p_on);
    drawLabelPic(label_wheel,right_info[1].p_on);
    for(int i=2;i<11;i++)
    {
        int x=right_info[i].x*factor,y=right_info[i].y*factor;
        int w=right_info[i].w*factor,h=right_info[i].h*factor;
        QString p=right_info[i].p_on;

        ((ClickLabel*)(right_info[i].widget))->setX(x);
        ((ClickLabel*)(right_info[i].widget))->setY(y);
        ((ClickLabel*)(right_info[i].widget))->setW(w);
        ((ClickLabel*)(right_info[i].widget))->setH(h);
        ((ClickLabel*)(right_info[i].widget))->setP(p);
        right_info[i].widget->setGeometry(x,y,w,h);
        repaint();
    }
}

void MainWindow::init_connect()
{
    timer_playpoint = new QTimer(this);
    timer_playpoint->setInterval(30);

    connect(timer_playpoint,SIGNAL(timeout()),
            this,SLOT(onPlayPoint()));

    connect(label_ctrl_start,SIGNAL(pressed()),
            this,SLOT(onStart()));
    connect(label_ctrl_acc,SIGNAL(pressed()),
            this,SLOT(onACC()));
    connect(label_ctrl_acc,SIGNAL(released()),
            this,SLOT(onACCrelease()));
}

void MainWindow::drawLabelPic(QLabel *label, QString p)
{
    QPixmap pix(p);
    QPixmap dst = pix.scaled(label->width(),label->height(),Qt::IgnoreAspectRatio,Qt::SmoothTransformation);
    label->setPixmap(dst);
}

void MainWindow::ontest()
{
    static float rotate=-156;
    rotate+=1;
    //QLabel * testlabel=new QLabel((QLabel *)label_background);
    label_background->setRoateLeft(rotate);
    label_background->setRoateRight(rotate);
    QString car_pic[4] = {":/pic/car_l_1.png",":/pic/car_l_2.png",":/pic/car_l_3.png",":/pic/car_l_4.png"};
    static int i = 0;
    drawLabelPic(label_car,car_pic[i]);
    i++;
    if(i==4)
        i=0;
}

void MainWindow::onbutton()
{
    label_background->setRoateRight(0);
}
void MainWindow::onStart()
{

}
void MainWindow::onACC()
{
    timer_playpoint->start(50);
}
void MainWindow::onACCrelease()
{
    timer_playpoint->stop();
}
void MainWindow::onPlayPoint()
{
    longpresstime+=50;
    carrpm = calculaterpm();
    carspeed = calculatespeed();
    int speed=carspeed;
    int rpmi =carrpm*10;
    float rpm = rpmi/10;
    label_background->setRoateRight(carspeed*1.56-156);
    label_background->setRoateLeft(carrpm*31.2-156);
    text_speed->setLabelText(QString::number(speed),35);
    text_rpm->setLabelText(QString::number(rpm),35);
}
float MainWindow::calculaterpm()
{
    return 1;
}
float MainWindow::calculatespeed()
{
    float value;
    //value=longpresstime/50;
    //任务三
    float presstime = longpresstime/1000;
    if(presstime<=6)
    {
        value=(110/36)*presstime*presstime
                +5*presstime;
    }
    else
    {
        value=200-(37500/((presstime-1)*(presstime-1)
                          *(presstime-1)*(presstime-1)));
    }
    //任务四
    return value;
}
