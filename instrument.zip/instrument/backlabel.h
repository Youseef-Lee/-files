#ifndef BACKLABEL_H
#define BACKLABEL_H
#include <QLabel>
#include <QPaintEvent>
#include <QPainter>
#include <QRadialGradient>
extern float g_factor;
class Backlabel:public QLabel
{
private:
    float factor = g_factor;
    float rotate_left;
    float rotate_right;
public:
    explicit Backlabel(QWidget * parent=0);
    ~Backlabel();
    void paintEvent(QPaintEvent *);
    void drawPoint(QPainter *p,float x,float y,float r);
    void setRoateLeft(float r);
    void setRoateRight(float r);
    float getRotateLeft();
    float getRotateRight();
};

#endif // BACKLABEL_H
