#ifndef TEXTLABEL_H
#define TEXTLABEL_H
#include <QLabel>
#include <QFont>
#include <QPalette>
#include <QPainter>
extern float g_factor;   //extern 外部声明/全局声明  拓展作用

class Textlabel:public QLabel
{
private:
    float factor =g_factor;
public:
    explicit Textlabel(QWidget *parent = 0);  //explicit  防止构造函数的参数被类型转换
    ~Textlabel();
    void setLabelText(QString str,int size);
};

#endif // TEXTLABEL_H
