#include "mainwindow.h"
#include <QApplication>
float g_factor = 1;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);  //a 程序任务管理器
    MainWindow w;    //w  程序界面
    w.setFixedSize((1396+800)*g_factor,781*g_factor);
    w.setWindowTitle("Instrument");

    w.show();

    return a.exec();
}
