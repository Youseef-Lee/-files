#include "clicklabel.h"

ClickLabel::ClickLabel(QWidget *parent):QLabel(parent)
{
    x=0;
    y=0;
    w=0;
    h=0;
    p="";
    ispressed = false;
}

ClickLabel::~ClickLabel()
{

}

void ClickLabel::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.save();
    QPixmap pix(p);
    if(ispressed)
    {
        QPixmap dst = pix.scaled((w-2),(h-2),Qt::KeepAspectRatio,Qt::SmoothTransformation);
        painter.drawPixmap(0,0,dst);
    }
    else
    {
        QPixmap pix(p);
        QPixmap dst = pix.scaled(w,h,Qt::KeepAspectRatio,Qt::SmoothTransformation);
        painter.drawPixmap(0,0,dst);
    }
    QPen pen;
    pen.setWidth(5*factor);
    pen.setColor(Qt::blue);
    if(ispressed)
    {
        painter.setPen(pen);
    }
    else
    {
        painter.setPen(Qt::NoPen);
    }
    painter.drawRect(0,0,w,h);
    painter.restore();
}

void ClickLabel::setX(float x)
{
    this->x=x;
}

void ClickLabel::setY(float y)
{
    this->y=y;
}

void ClickLabel::setW(float w)
{
    this->w=w;
}

void ClickLabel::setH(float h)
{
    this->h=h;
}

void ClickLabel::setP(QString p)
{
    this->p=p;
}

void ClickLabel::mousePressEvent(QMouseEvent *event)
{
    if(event->button()==Qt::LeftButton)
    {
        ispressed=true;
        emit pressed();
        repaint();
    }
    QLabel::mousePressEvent(event);
}

void ClickLabel::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button()==Qt::LeftButton)
    {
        ispressed=false;
        emit released();
        repaint();
    }
    QLabel::mouseReleaseEvent(event);
}

