#include "backlabel.h"

Backlabel::Backlabel(QWidget * parent):QLabel(parent)
{
    rotate_left=-156;
    rotate_right=-156;
    setGeometry(0,0,1391,781);
}

Backlabel::~Backlabel()
{

}

void Backlabel::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix(":/pic/background_1.png");
    QPixmap dst=pix.scaled(1396*factor,781*factor,Qt::IgnoreAspectRatio,Qt::SmoothTransformation);
    painter.drawPixmap(0,0,dst);
    drawPoint(&painter,354,453,rotate_left);
    drawPoint(&painter,1040,453,rotate_right);
}

void Backlabel::drawPoint(QPainter *painter,float x,float y,float r)
{
    painter->save();
    painter->translate(x*factor,y*factor);
    QPainterPath pt;   //按路径描述一个图形
    pt.moveTo(2.5*factor,0*factor);
    pt.lineTo(0.25*factor,-157*factor);
    pt.lineTo(-0.25*factor,-157*factor);
    pt.lineTo(-2.5*factor,0*factor);
    pt.arcTo(-2.5*factor,0*factor,5*factor,5*factor,180*factor,180*factor);
    QPainterPath in;
    in.addEllipse(-1.25*factor,-1.25*factor,2.5*factor,2.5*factor);
    QRadialGradient radient(0,0,157*factor,0,0);
    radient.setColorAt(0,QColor(0,199,140,160));
    radient.setColorAt(1,QColor(255,199,150,160));
    painter->setBrush(radient);
    painter->rotate(r);
    painter->setRenderHint(QPainter::Antialiasing,true);   //反锯齿
    painter->drawPath(pt.subtracted(in));
    painter->restore();
}

void Backlabel::setRoateLeft(float r)
{
    rotate_left = r;
    repaint();
}

void Backlabel::setRoateRight(float r)
{
    rotate_right = r;
    update();
}

float Backlabel::getRotateLeft()
{
    return rotate_left;
}

float Backlabel::getRotateRight()
{
    return rotate_right;
}
