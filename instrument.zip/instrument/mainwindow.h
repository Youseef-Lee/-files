#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QLabel>
#include <QTimer>        //计时器
#include <QPixmap>
#include <QList>         //容器
#include <QDateTime>     //获取系统时间
#include <QDebug>        //调试
#include "textlabel.h"
#include "backlabel.h"
#include "iconinfo.h"
#include "clicklabel.h"

extern float g_factor;
QT_BEGIN_INCLUDE_NAMESPACE
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    //QList<struct IconInfo>left_info;
    //变量容器定义
    Backlabel*label_background;
    QList<struct IconInfo> left_info;
    QList<struct IconInfo> right_info;
    QList<QString> carlist;
    QList<QString> gearlist;

    Textlabel *text_info;
    Textlabel *text_speed;
    Textlabel *text_rpm;
       //左侧仪表盘界面
    QLabel *label_safety;
    QLabel *label_oil;
    QLabel *label_temp;
    QLabel *label_engine;
    QLabel *label_door;
    QLabel *label_led;
    QLabel *label_ble;
    QLabel *label_turn_left;
    QLabel *label_turn_right;
    QLabel *label_car;
    QLabel *label_bottom;
       // 右侧仿真方向盘控件
    QLabel *label_ctrl;
    QLabel *label_wheel;
    ClickLabel *label_ctrl_start;
    ClickLabel *label_ctrl_turn_right;
    ClickLabel *label_ctrl_turn_left;
    ClickLabel *label_ctrl_up;
    ClickLabel *label_ctrl_down;
    ClickLabel *label_ctrl_acc;
    ClickLabel *label_ctrl_dac;
    ClickLabel *label_ctrl_left;
    ClickLabel *label_ctrl_right;


    float factor = g_factor;
    float carspeed;
    float carrpm;
    float longpresstime;

    QTimer  * timer_playpoint;
    //初始化区
    void init_left();
    void init_left_date();
    void init_left_ui();
    void init_right();
    void init_right_date();
    void init_right_ui();

    void init_connect();
    //功能区
    void drawLabelPic(QLabel * label,QString p);
    float calculatespeed();
    float calculaterpm();
    //动画区   计时器响应
public slots:   //定义槽函数
    void ontest();
    void onPlayPoint();
    //逻辑功能区  按键响应区
    void onbutton();

    void onStart();
    void onACC();
    void onACCrelease();
private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
