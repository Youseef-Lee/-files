#ifndef CLICKLABEL_H
#define CLICKLABEL_H
#include <QLabel>
#include <QPaintEvent>
#include <QPainter>
#include <QPixmap>
#include <QMouseEvent>
#include <QPen>
extern float g_factor;

class ClickLabel:public QLabel
{
    Q_OBJECT
public:
    explicit ClickLabel(QWidget *parent=0);
    ~ClickLabel();
    void paintEvent(QPaintEvent *);
    void setX(float x);
    void setY(float y);
    void setW(float w);
    void setH(float h);
    void setP(QString p);
private:
    float x;
    float y;
    float w;
    float h;
    QString p;
    float factor = g_factor;
    bool ispressed;
protected:
    virtual void mousePressEvent(QMouseEvent *);
    virtual void mouseReleaseEvent(QMouseEvent *);
signals:
    void pressed();
    void released();
};

#endif // CLICKLABEL_H
