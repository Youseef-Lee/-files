#include "textlabel.h"

Textlabel::Textlabel(QWidget * parent):QLabel(parent)
{

}

Textlabel::~Textlabel()
{

}

void Textlabel::setLabelText(QString str,int size)
{
    setText(str);
    setAlignment(Qt::AlignCenter);
    QPalette palette;
    palette.setColor(QPalette::WindowText,Qt::white);
    setPalette(palette);
    QFont font;
    font.setPointSize(size*factor);
    setFont(font);
}
